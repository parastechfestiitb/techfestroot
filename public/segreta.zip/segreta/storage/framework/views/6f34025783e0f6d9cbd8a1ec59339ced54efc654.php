<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Level <?php echo e($level); ?> | Segreta | Techfest</title>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        @import  url('https://fonts.googleapis.com/css?family=Krub');
        *{
            font-family: 'Krub', sans-serif;
        }
        html,body{
            height: 100%;
            width: 100%;
            overflow:hidden;
        }
        .main-image{
            transition: all 0.1s;
        }
        .zi-10{
            z-index: 10;
        }
        .overflow-hidden{
            overflow: hidden;
        }
        .overflow-auto{
            overflow: auto;
        }
        .img-container{
            max-height: 60vh;
            margin:auto;
        }
        .normal-container{
            max-width: 500px;
            margin:auto;
        }
    </style>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <link rel="manifest" href="/manifest.json" />
    <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
    <script>
        var OneSignal = window.OneSignal || [];
        OneSignal.push(function() {
            OneSignal.init({
                appId: "a5f3d20c-79a4-40e2-b85b-4336d5f708a0",
            });
        });
    </script>
</head>
<body>
<main class="d-flex flex-column h-100 w-100">
    <nav class="navbar navbar-expand navbar-dark bg-dark zi-10"><a class="navbar-brand" href="#">Segreta</a>
        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"></li>
                <li class="nav-item"><a class="nav-link" href="#">Rules</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Forum</a></li>
            </ul>
        </div>
    </nav>
    <div class="container mt-3 text-center h-100 overflow-auto mb-3">
        <div class="img-container overflow-hidden">
            <img class="main-image img-fluid m-auto" src="<?php echo $image; ?>" alt="segreta-question"/>
        </div>
        <div class="normal-container">
            <form action="<?php echo e(url()->current()); ?>" method="POST"><?php echo csrf_field(); ?>
                <div class="input-group mb-3 mt-3">
                    <input class="form-control" placeholder="Your Answer" aria-label="Your Answer" aria-describedby="basic-addon1" type="text" name="answer"/>
                </div>
                <div class="input-group">
                    <input class="form-control bg-dark text-white" type="submit" value="Check"/>
                </div>
            </form>
            <div class="mt-3 w-100 d-flex">
                <a class="badge badge-pill badge-success p-3 mr-auto text-white" href="<?php echo $image; ?>" download="image.jpg" target="_blank">
                    <i class="fa fa-download"></i><span>&nbsp;Download Image</span>
                </a>
                <span class="badge badge-pill rotate-left p-3 badge-primary ml-5">
                    <i class="fa fa-rotate-left"></i>
                </span>
                <span class="badge badge-pill rotate-right p-3 badge-primary ml-1">
                    <i class="fa fa-rotate-right"> </i>
                </span>
            </div>
        </div>
    </div>
    <footer class="bg-dark p-2 text-white">
        <div class="d-flex">
            <div class="mr-auto">&copy; Techfest 2018-19</div>
            <div><a class="text-white" href="https://techfest.org/legal">T&amp;C</a></div>
        </div>
    </footer>
</main>

<script>
    let rotation = 0;
    let rotateImg = function () {
        $('.main-image').css('transform', `rotate(${rotation}deg)`);
    };
    $('.rotate-left').click(function(){
        rotation-=90;
        rotateImg();
    });
    $('.rotate-right').click(function(){
        rotation+=90;
        console.log('yo');
        rotateImg();
    });
    <?php if(session()->has('error')): ?>
    $(document).ready(function(){
        izi.error({'message':'Sorry <?php echo e(session('error')); ?> is not the correct answer'});
    });
    <?php endif; ?>
</script>
</body>
</html>