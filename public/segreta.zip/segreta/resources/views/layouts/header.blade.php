<nav class="navbar navbar-expand navbar-dark bg-dark zi-10">
    <a class="navbar-brand" href="https://techfest.org/segreta/">Segreta</a>
    <a class="navbar-brand" href="javascript:void(null)"><img src="https://techfest.org/segreta/sponsor.png" style="height: 40px" alt=""></a>
    <div class="collapse navbar-collapse" id="navbarColor01">
        <ul class="navbar-nav ml-auto">
            @if(auth()->check())
                <li class="nav-item"><a class="nav-link text-danger" href="{{route('logout')}}">Logout</a></li>
            @endif
        </ul>
    </div>
</nav>