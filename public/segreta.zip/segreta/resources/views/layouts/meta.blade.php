<meta property="og:url" content="{{url()->current()}}">
<meta property="og:description" content="Welcome aboard, time to turn ON the Sherlock inside you. Register and get started to the stand a chance to win prizes worth INR 40,000. Read the rules and visit the Forum regularly for hints and important information.">
<meta property="og:title" content="Segreta | Techfest 2018-19">
<meta property="og:site_name" content="Techfest 2018-19">
<meta property="og:image" content="https://techfest.org/odrb6utl1e/segreta.png">
<meta property="og:see_also" content="https://m.techfest.org">
<link rel="icon" href="https://techfest.org/favicon.png">
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-81222017-1"></script>
<script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', 'UA-81222017-1');</script>
