<footer class="fixed-bottom p-2 container bg-white">
    <div class="d-md-flex text-black-50">
        <div class="mr-auto copyrit"><a class="text-dark" href="https://techfest.org/">&copy; Techfest 2018-19</a></div>
        <div class="d-flex">
            <div class="mr-4"><a class="text-dark" href="https://techfest.org/segreta/redirect">Questions</a></div>
            <div class="mr-4"><a class="text-dark" href="{{route('leaderboard')}}">Leaderboard</a></div>
            <div class="mr-4"><a href="https://www.facebook.com/iitbombaytechfest/app/202980683107053/" class="text-dark">Forum</a></div>
            <div><a class="text-dark" href="{{route('rule')}}">Rules</a></div>
        </div>
    </div>
</footer>