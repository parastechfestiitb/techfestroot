<?php
Route::get('/admin/create/ybsoserious','MainController@adminCreate');
Route::get('/','MainController@Get')->name('index');
Route::get('/leaderboard','MainController@leaderBoardGet')->name('leaderboard')->middleware(['auth','verified']);;
Route::get('/level/{id}', 'MainController@levelGet')->name('level')->middleware(['auth','verified']);
Route::post('/level/{id}', 'MainController@levelPost')->middleware('verified');
Route::get('/rules','MainController@rulesGet')->name('rule');
Route::redirect('/home','/redirect');
Route::get('/redirect', 'MainController@redirect')->name('home');
Route::get('/logout','MainController@logout')->name('logout');
Auth::routes(['verify' => true]);
Route::get('/share/{id}/{name}','MainController@share');
Route::get('/admin/qwertymnbv09',function(){
   return User::get();
})->middleware('admin');