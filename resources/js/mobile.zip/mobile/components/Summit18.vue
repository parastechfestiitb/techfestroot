<template>

</template>

<script>
    export default {
        name: "Summit",
        created: function(){
            window.location.href = 'https://techfest.org/summit18/';
            window.location.reload();
        }
    }
</script>

<style scoped>
</style>