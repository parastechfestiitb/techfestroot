<template>
    <main>
        <div class="heading">
            Contact
        </div>
        <div class="teams row">
            <div class="col-6 member">
                <div class="name">Sourabh Surage</div>
                <a href="mailto:sourabh@techfest.org" class="email">sourabh@techfest.org</a>
                <a href="tel:73545452478" class="phone">73545452478</a>
            </div>
            <div class="col-6 member">
                <div class="name">Adarsh Rathi</div>
                <a href="mailto:adarshrathi@techfest.org" class="email">adarshrathi@techfest.org</a>
                <a href="tel:9987091615" class="phone">9987091615</a>
            </div>
        </div>
        <div class="heading">
            Sponsors
        </div>
        <div class="text-center text-white">
            To Be Updated Soon
        </div>
    </main>
</template>

<script>
    export default {
        name: "Sponsors"
    }
</script>

<style scoped>
    .heading{
        margin-top: 70px;
        color: white;
        text-align: center;
        font-size: 2em;
    }
    .teams{
        width:100%;
    }
    .member{
        padding:1rem;
        display: inline-block;
        text-align: center;
    }
    .member .name{
        font-size: 1.3em;
        color:white;
    }
    .member .email,.member .phone{
        color:white;
        text-decoration: none;
    }
</style>