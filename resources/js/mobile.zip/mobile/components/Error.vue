<template>
</template>

<script>

    export default {
        name: "Error",
        created:function(){
            window.location.reload();
        }
    }
</script>

<style scoped>

</style>