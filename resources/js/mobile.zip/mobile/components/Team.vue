<template>
    <main>
        <div class="row text-center">
            <div class="col-12 col-sm-12">
                <div class="ourteam">OUR TEAM</div>
            </div>
            <br>
            <div class="col-12 col-sm-12 mb-3">
                <img src="https://techfest.org/2018/Team/Kala.jpg" alt="oc" class="oc picture">
                <br>
                <div class="name">
                    Himanshu Kala
                </div>
                <div class="des">
                    Overall Coordinator
                </div>
                <div class="email">
                    <a href="mailto:himanshu@techfest.org">himanshu@techfest.org</a>
                </div>
            </div>
            <template v-for="t in team">
                <div class="col-6 col-sm-6 mb-3" v-for="person in t[2]">
                    <div>
                        <img :src="'https://techfest.org/2018/Team/'+person.img+'.jpg'" class="picture" alt="picture">
                        <br>
                        <div class="name" v-html="person.name">
                        </div>
                        <div class="des" v-html="t[1]+' Manager'">
                        </div>
                        <div class="email">
                            <a :href="'mailto:'+person.email">{{person.email}}</a>
                        </div>
                        <div class="phone">
                            <a :href="'tel:'+person.phone">{{person.phone}}</a>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </main>
</template>

<script>
    export default {
        name: "Team",
        data:function(){
            return{
                team: {
                    'marki': [
                        'marki',
                        'Marketing',
                        [
                            {

                                'name': 'Adarsh Rathi',
                                'email': "adarshrathi@techfest.org",
                                'phone': '+91 998 709 1615',
                                'img': 'rathi'
                            },
                            {

                                'name': 'Sourabh Surage',
                                'email': "sourabh@techfest.org",
                                'phone': '+91 735 454 5247',
                                'img': 'sourabh'
                            }
                        ]

                    ],
                    'media': [
                        'media',
                        'Media &nbsp;&nbsp;&nbsp;<br>& Publicity',
                        [
                            {

                                'name': 'Suseendran Baskaran',
                                'email': "suseendran@techfest.org",
                                'phone': '+91 965 554 6091',
                                'img': 'susee'
                            },
                            {

                                'name': 'Bhadri Narayanan',
                                'email': "bhadri@techfest.org",
                                'phone': '+91 829 147 3913',
                                'img': 'bhadri'
                            }
                        ]

                    ],
                    'compi': [
                        'compi',
                        'Competitions',
                        [
                            {

                                'name': 'Abhishek Singhal',
                                'email': "abhishek@techfest.org",
                                'phone': '+91 829 147 3951',
                                'img': 'abhishek'
                            },
                            {

                                'name': 'Atharv Nandapurkar',
                                'email': "atharv@techfest.org",
                                'phone': '+91 702 148 2253',
                                'img': 'atharv'
                            }
                        ]
                    ],
                    'ideate': [
                        'ideate',
                        'Ideate &amp; Accounts',
                        [
                            {

                                'name': 'Rohan Gurav',
                                'email': "rohan@techfest.org",
                                'phone': '+91 869 208 2029',
                                'img': 'rohan'
                            }
                        ]

                    ],
                    'lectures': [
                        'lectures',
                        'Lectures',
                        [
                            {

                                'name': 'Anumay Ashish',
                                'email': "anumay@techfest.org",
                                'phone': '+91 998 709 2623',
                                'img': 'anumay'
                            }
                        ]

                    ],
                    'robowars': [
                        'robowars',
                        'Robowars',
                        [
                            {

                                'name': 'Devavrat Mahajan',
                                'email': "devavrat@techfest.org",
                                'phone': '+91 913 047 5759',
                                'img': 'dev'
                            },
                            {

                                'name': 'Kanishk Samriya',
                                'email': "kanishk@techfest.org",
                                'phone': '+91 946 031 3067',
                                'img': 'kanishk'
                            }
                        ]
                    ],
                    'exhi': [
                        'exhi',
                        'Exhibitions',
                        [
                            {

                                'name': 'Prathamesh Sagare',
                                'email': "prathamesh@techfest.org",
                                'phone': '+91 836 959 7198',
                                'img': 'prathamesh'
                            },
                            {

                                'name': 'Akash Kumar',
                                'email': "akash@techfest.org",
                                'phone': '+91 998 799 1539',
                                'img': 'akash'
                            }
                        ]

                    ],
                    'ozone': [
                        'ozone',
                        'Ozone',
                        [
                            {

                                'name': 'Piyush Dharpure',
                                'email': "piyush@techfest.org",
                                'phone': '+91 8349907069',
                                'img': 'piyush'
                            },
                            {

                                'name': 'Akshita Goyal',
                                'email': "akshita@techfest.org",
                                'phone': '+91 887 273 8722',
                                'img': 'akshita'
                            }
                        ]

                    ],
                    'techx': [
                        'techx',
                        'Technoholix',
                        [
                            {

                                'name': 'Avani Mangal',
                                'email': "avani@techfest.org",
                                'phone': '+91 702 148 2461',
                                'img': 'avani'
                            },
                            {

                                'name': 'Shivam Pundir',
                                'email': "shivam@techfest.org",
                                'phone': '+91 817 801 8921',
                                'img': 'shivam'
                            }
                        ]

                    ],
                    'hospi': [
                        'hospi',
                        'Hospitality&nbsp;&amp; F&B&nbsp;',
                        [
                            {

                                'name': 'Sahil Singh',
                                'email': "sahil@techfest.org",
                                'phone': '+91 870 807 2652',
                                'img': 'sahil'
                            },
                            {

                                'name': 'Aniket Ranade',
                                'email': "aniket@techfest.org",
                                'phone': '+91 942 007 0946',
                                'img': 'aniket'
                            }
                        ]

                    ],
                    'infra': [
                        'infra',
                        'Infrastructure',
                        [
                            {

                                'name': 'Himanshu Rathore',
                                'email': "rathore@techfest.org",
                                'phone': '+91 998 709 1558',
                                'img': 'himanshu'
                            },
                            {

                                'name': 'Ankur Samdarshi',
                                'email': "ankur@techfest.org",
                                'phone': '+91 829 147 3973',
                                'img': 'ankur'
                            }
                        ]

                    ],
                    'wnc': [
                        'wnc',
                        'Web & Creatives',
                        [
                            {

                                'name': 'Adarsh Malviya',
                                'email': "adarshmalviya@techfest.org",
                                'phone': '+91 999 357 7029',
                                'img': 'malviya'
                            },
                            {

                                'name': 'Vaibhaw',
                                'email': "vaibhaw@techfest.org",
                                'phone': '+91 829 147 5004',
                                'img': 'vaibhaw'
                            }
                        ]

                    ]
                }
            }
        }
    }
</script>

<style scoped>
    main
    {
        color: #fff;
        padding-top: 80px;
    }
    .picture
    {
        width: 80%;
        height: auto;
    }
    .oc
    {
        width: 60% !important;
    }
    a
    {
        font-size: 16px;
        text-decoration: none !important;
        color: white !important;

    }
    .ourteam
    {
        font-size: 30px;
        font-weight: bold;
        font-family: play;
    }
    .email{
        font-size:0.9em;
    }
</style>
